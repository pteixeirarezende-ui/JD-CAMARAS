const overviewView = document.querySelector('#overview-view');
const componentsView = document.querySelector('#components-view');
const overviewLink = document.querySelector('.catalog-nav a[href="#overview"]');
const componentsLink = document.querySelector('.catalog-nav a[href="#components"]');
const sidebarLinks = [...document.querySelectorAll('.components-sidebar a')];
const componentIds = new Set(sidebarLinks.map(link => link.hash.slice(1)));

function renderRoute() {
  const id = location.hash.slice(1) || 'overview';
  const showComponents = id === 'components' || componentIds.has(id);
  overviewView.hidden = showComponents;
  componentsView.hidden = !showComponents;
  overviewLink.toggleAttribute('aria-current', !showComponents);
  componentsLink.toggleAttribute('aria-current', showComponents);

  if (showComponents && componentIds.has(id)) {
    requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView());
  } else if (showComponents) {
    componentsView.scrollTop = 0;
  }
}

const observer = new IntersectionObserver(entries => {
  const visible = entries
    .filter(entry => entry.isIntersecting)
    .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
  if (!visible) return;
  for (const link of sidebarLinks) {
    link.toggleAttribute('aria-current', link.hash === `#${visible.target.id}`);
  }
}, {root: componentsView, rootMargin: '-10% 0px -70%', threshold: [0, .1, .5]});

for (const group of document.querySelectorAll('.component-group')) observer.observe(group);
window.addEventListener('hashchange', renderRoute);
renderRoute();
